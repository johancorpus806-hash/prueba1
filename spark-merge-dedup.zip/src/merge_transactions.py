
import argparse
from pyspark.sql import SparkSession, functions as F, types as T
from pyspark.sql.window import Window

def parse_args():
    p = argparse.ArgumentParser(description="Merge & dedupe financial transactions with PySpark")
    p.add_argument("--input1", required=True, help="Path to first CSV")
    p.add_argument("--input2", required=True, help="Path to second CSV")
    p.add_argument("--output", required=True, help="Directory to write outputs")
    p.add_argument("--strict-date-validation", default="false", choices=["true","false"],
                   help="If true, invalidates years > 2100 to avoid picking them as the most recent")
    return p.parse_args()

def build_spark():
    return (SparkSession.builder
            .appName("merge-dedupe-transactions")
            .master("local[*]")
            .getOrCreate())

def main():
    args = parse_args()
    strict = args.strict_date_validation.lower() == "true"
    spark = build_spark()

    schema = T.StructType([
        T.StructField("ID", T.IntegerType(), False),
        T.StructField("Date", T.StringType(), True),  # parse later
        T.StructField("Amount", T.StringType(), True), # parse later to Decimal
        T.StructField("Currency", T.StringType(), True),
    ])

    df1 = (spark.read
           .option("header", True)
           .schema(schema)
           .csv(args.input1)
           .withColumn("source", F.lit("df1")))

    df2 = (spark.read
           .option("header", True)
           .schema(schema)
           .csv(args.input2)
           .withColumn("source", F.lit("df2")))

    df = df1.unionByName(df2, allowMissingColumns=True)

    # Parse and standardize
    # Amount to Decimal(18,2)
    df = df.withColumn("Amount_num", F.when(F.col("Amount").rlike(r"^\d+(\.\d+)?$"), F.col("Amount").cast(T.DecimalType(18,2))).otherwise(None))

    # Parse Date
    date_col = F.to_date("Date", "yyyy-MM-dd")
    if strict:
        # Invalidate years > 2100
        year = F.year(date_col)
        df = df.withColumn("Date_parsed", F.when(year <= 2100, date_col).otherwise(F.lit(None).cast(T.DateType())))
    else:
        df = df.withColumn("Date_parsed", date_col)

    # Drop exact duplicates
    df = df.dropDuplicates(["ID", "Date", "Amount", "Currency"])

    # Window to pick most recent per ID; tie-breaker by Amount desc, then source as final tiebreaker
    w = Window.partitionBy("ID").orderBy(F.col("Date_parsed").desc_nulls_last(), F.col("Amount_num").desc_nulls_last(), F.col("source").desc())

    df_ranked = df.withColumn("rn", F.row_number().over(w))

    final_df = (df_ranked
                .filter(F.col("rn") == 1)
                .select("ID", F.col("Date_parsed").alias("Date"), F.col("Amount_num").alias("Amount"), "Currency")
                .orderBy("ID"))

    # Write outputs
    final_df.write.mode("overwrite").parquet(f"{args.output}/final_transactions.parquet")
    # Also write a CSV preview
    (final_df
     .coalesce(1)
     .write
     .mode("overwrite")
     .option("header", True)
     .csv(f"{args.output}/preview.csv"))

    # Show to console for quick check
    final_df.show(truncate=False)

    spark.stop()

if __name__ == "__main__":
    main()
